package com.fis.bankapplication.exceptions;

public class NotEnoughBalanceException extends Exception {
	public NotEnoughBalanceException(String message) {
		super(message);
	}
}
